package gsd.inescid.markpledge.smartclient.connection;

public enum CardConnectionType {
	MULTOS, MULTOS_SIM, JCOP_SIM, JAVA, PC_SIM, CARD
}
